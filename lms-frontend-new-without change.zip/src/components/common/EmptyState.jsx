import './common.css'

const EmptyState = ({
  message = 'No data found',
  subtext = '',
  action = null,
  icon = null,
}) => (
  <div className="empty-state">
    <div className="empty-state__icon">
      {icon || (
        <svg
          width="40"
          height="40"
          viewBox="0 0 24 24"
          fill="none"
          stroke="var(--text-muted)"
          strokeWidth="1.5"
        >
          <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
        </svg>
      )}
    </div>

    <p className="empty-state__message">{message}</p>

    {subtext && <p className="empty-state__subtext">{subtext}</p>}

    {action && <div className="empty-state__action">{action}</div>}
  </div>
)

export default EmptyState